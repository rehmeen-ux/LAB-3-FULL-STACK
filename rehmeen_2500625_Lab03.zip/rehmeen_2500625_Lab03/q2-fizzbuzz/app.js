

const limitInput = document.getElementById("limit");
const generateButton = document.getElementById("generateButton");
const fizzBuzzList = document.getElementById("fizzBuzzList");


function generateFizzBuzz() {
    const limit = Number(limitInput.value);

    fizzBuzzList.innerHTML = "";

    if (limit < 1 || Number.isNaN(limit)) {
        const errorItem = document.createElement("li");
        errorItem.textContent = "Please enter a valid upper limit.";
        fizzBuzzList.appendChild(errorItem);
        return;
    }

    for (let number = 1; number <= limit; number++) {
        const listItem = document.createElement("li");

        if (number % 3 === 0 && number % 5 === 0) {
            listItem.textContent = "FizzBuzz";
        } else if (number % 3 === 0) {
            listItem.textContent = "Fizz";
        } else if (number % 5 === 0) {
            listItem.textContent = "Buzz";
        } else {
            listItem.textContent = number;
        }

        fizzBuzzList.appendChild(listItem);
    }
}

generateButton.addEventListener("click", generateFizzBuzz);

generateFizzBuzz();
