

const temperatureInput = document.getElementById("temperature");
const fahrenheitButton = document.getElementById("toFahrenheit");
const celsiusButton = document.getElementById("toCelsius");
const result = document.getElementById("result");

// Converts Celsius to Fahrenheit.
function celsiusToFahrenheit(c) {
    return (c * 9 / 5) + 32;
}

// Converts Fahrenheit to Celsius.
const fahrenheitToCelsius = (f) => {
    return (f - 32) * 5 / 9;
};

// Gets the input temperature.
function getTemperature() {
    const value = temperatureInput.value.trim();

    if (value === "" || Number.isNaN(Number(value))) {
        result.textContent = "Please enter a valid number.";
        return null;
    }

    return Number(value);
}

// Converts the temperature to Fahrenheit.
function convertToFahrenheit() {
    const temperature = getTemperature();

    if (temperature === null) {
        return;
    }

    const answer = celsiusToFahrenheit(temperature);
    result.textContent = `${temperature} °C = ${answer.toFixed(1)} °F`;
}

// Converts the temperature to Celsius.
function convertToCelsius() {
    const temperature = getTemperature();

    if (temperature === null) {
        return;
    }

    const answer = fahrenheitToCelsius(temperature);
    result.textContent = `${temperature} °F = ${answer.toFixed(1)} °C`;
}

fahrenheitButton.addEventListener("click", convertToFahrenheit);
celsiusButton.addEventListener("click", convertToCelsius);
